# Applying the update

1. Close the dev servers. Back up your project (or commit it to git first).
2. Copy the contents of this zip into your project folder, replacing files when asked:
   - backend/api.py, backend/schemas.py (rupee version)
   - frontend/src/App.jsx, api.js, index.css
   - frontend/src/components/ (Login, ScoreForm, ResultCard, History)
   - requirements.txt, .gitignore
3. Move the old UI files you no longer use into Backup/old-ui/ (do not delete them yet):
   DetailSheet.jsx, DriftPanel.jsx, HistoryCarousel.jsx, MonitoringPanel.jsx,
   ScoreRing.jsx, SimulatorPanel.jsx, TopNav.jsx
4. Backend (from the project root):
       pip install -r requirements.txt
       python backend/api.py
5. Frontend (new terminal):
       cd frontend
       npm run dev
   Open http://localhost:5173
6. Run `pip freeze > requirements.txt` in your venv to pin the exact versions your model was trained with.
